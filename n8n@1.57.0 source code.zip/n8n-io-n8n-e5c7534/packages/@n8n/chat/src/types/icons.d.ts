declare module 'virtual:icons/*' {
	import { FunctionalComponent, SVGAttributes } from 'vue';
	const component: FunctionalComponent<SVGAttributes>;
	export default component;
}
