export const localStorageNamespace = 'n8n-chat';
export const localStorageSessionIdKey = `${localStorageNamespace}/sessionId`;
